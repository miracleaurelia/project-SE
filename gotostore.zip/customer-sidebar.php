<div class="user-sidebar">
    <ul>
    <a href="dashboard.php"><button class="btn btn-danger"><?php echo "Dashboard"; ?></button></a>
    <a href="customer-profile-update.php"><button class="btn btn-danger"><?php echo "Update Profile"; ?></button></a>
    <a href="customer-billing-shipping-update.php"><button class="btn btn-danger"><?php echo "Update Billing and Shipping Info"; ?></button></a>
    <a href="customer-password-update.php"><button class="btn btn-danger"><?php echo "Update Password"; ?></button></a>
    <a href="customer-order.php"><button class="btn btn-danger"><?php echo "Orders"; ?></button></a>
    <a href="logout.php"><button class="btn btn-danger"><?php echo "Logout"; ?></button></a>
    </ul>
</div>